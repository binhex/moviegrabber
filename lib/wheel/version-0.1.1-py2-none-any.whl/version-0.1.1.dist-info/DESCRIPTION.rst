`version` lives on `GitHub <http://github.com/halst/version/>`_.


